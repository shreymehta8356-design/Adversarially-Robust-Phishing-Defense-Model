"""Audit a real corpus before anything is trained on it.

A public-corpus result is only as good as the corpus, and the ways public
phishing corpora go wrong are specific and well documented:

1. **Era confounds.** The standard pairing -- Nazario phishing (2005-2025)
   with Enron (to 2001) or SpamAssassin (2002-2003) legitimate mail -- puts
   the two classes in different decades. A classifier can then separate them
   by *date*, and by everything that changes with date: DMARC did not exist
   until 2012 and ``Authentication-Results`` until RFC 5451 in 2009, so in
   that merge "carries a DMARC verdict" predicts *phishing* perfectly -- the
   exact inverse of what it means in a live mailbox.
2. **Source artefacts.** Each corpus has its own formatting fingerprint (hop
   count, header set, HTML conventions). A model that learns the fingerprint
   scores brilliantly and has learned nothing about phishing.
3. **Label noise.** The same message appearing in both classes.
4. **Silent parse loss.** Mis-decoded charsets, HTML-only mail with no text,
   encoded subjects -- each quietly corrupts features.

The confound audit is the heart of this module. It asks how well *metadata
with no phishing meaning* predicts the label. If receipt year alone scores
0.97 AUC, a high accuracy on that corpus is evidence of a dating problem, not
of a detector. The audit cannot prove a corpus is clean -- but it catches the
confounds that most published results on these corpora never checked for.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from phishguard.data.loaders import UNDATED, LoadReport, load_any
from phishguard.data.splits import find_near_duplicates, single_feature_auc
from phishguard.schemas import EmailMessage

#: Single-feature AUC above which a metadata feature is flagged as a confound.
CONFOUND_WARN = 0.80
CONFOUND_SEVERE = 0.95


@dataclass
class Finding:
    level: str  # "ok" | "warn" | "fail"
    check: str
    detail: str
    fix: str = ""

    def as_dict(self) -> dict[str, str]:
        return {"level": self.level, "check": self.check, "detail": self.detail, "fix": self.fix}


@dataclass
class CorpusAudit:
    n: int = 0
    n_phish: int = 0
    n_ham: int = 0
    sources: list[dict[str, Any]] = field(default_factory=list)
    by_source: dict[str, dict[str, int]] = field(default_factory=dict)
    confounds: list[dict[str, Any]] = field(default_factory=list)
    year_range: dict[str, Any] = field(default_factory=dict)
    duplicates: dict[str, int] = field(default_factory=dict)
    coverage: dict[str, float] = field(default_factory=dict)
    findings: list[Finding] = field(default_factory=list)

    @property
    def verdict(self) -> str:
        levels = {f.level for f in self.findings}
        if "fail" in levels:
            return "NOT READY"
        if "warn" in levels:
            return "READY WITH WARNINGS"
        return "READY"

    def as_dict(self) -> dict[str, Any]:
        return {
            "verdict": self.verdict,
            "n": self.n,
            "n_phish": self.n_phish,
            "n_ham": self.n_ham,
            "sources": self.sources,
            "by_source": self.by_source,
            "confounds": self.confounds,
            "year_range": self.year_range,
            "duplicates": self.duplicates,
            "coverage": self.coverage,
            "findings": [f.as_dict() for f in self.findings],
        }


def _metadata_features(messages: list[EmailMessage]) -> dict[str, np.ndarray]:
    """Features that describe *how* a message was captured, not what it says.

    None of these should carry phishing meaning in a well-built corpus. Each
    one that separates the classes is a way for a model to cheat.
    """

    def year(m: EmailMessage) -> float:
        return float(m.received_at.year) if m.received_at != UNDATED else np.nan

    years = np.array([year(m) for m in messages], dtype=np.float64)
    finite = years[np.isfinite(years)]
    fill = float(np.median(finite)) if finite.size else 0.0
    return {
        "receipt year": np.where(np.isfinite(years), years, fill),
        "is undated": np.array([m.received_at == UNDATED for m in messages], dtype=float),
        "has any auth verdict": np.array(
            [
                m.auth.spf != "none" or m.auth.dkim != "none" or m.auth.dmarc != "none"
                for m in messages
            ],
            dtype=float,
        ),
        "has a DMARC verdict": np.array([m.auth.dmarc != "none" for m in messages], dtype=float),
        "Received-hop count": np.array([m.received_hops for m in messages], dtype=float),
        "has an HTML part": np.array([bool(m.html_body) for m in messages], dtype=float),
        "recipient count": np.array([len(m.to) for m in messages], dtype=float),
        "has Return-Path": np.array([bool(m.return_path) for m in messages], dtype=float),
    }


def audit_corpus(
    specs: list[str],
    *,
    limit: int | None = None,
    spam_as: str = "skip",
    near_duplicate_threshold: float = 0.9,
) -> tuple[CorpusAudit, list[EmailMessage], list[int]]:
    """Load every spec, then run every check. Returns the audit and the data."""
    audit = CorpusAudit()
    messages: list[EmailMessage] = []
    labels: list[int] = []

    for spec in specs:
        report = LoadReport()
        try:
            m, y = load_any(spec, limit=limit, spam_as=spam_as, report=report)
        except (OSError, ValueError) as exc:
            audit.findings.append(
                Finding(
                    "fail",
                    f"load {spec}",
                    str(exc),
                    "Check the path exists and add #phish or #ham for single-class corpora.",
                )
            )
            continue
        audit.sources.append({"spec": spec, **report.as_dict()})
        audit.by_source[spec] = {"phishing": int(sum(y)), "legitimate": int(len(y) - sum(y))}
        messages.extend(m)
        labels.extend(y)

        if report.read and report.kept / report.read < 0.9:
            audit.findings.append(
                Finding(
                    "warn",
                    f"parse loss in {spec}",
                    f"kept {report.kept} of {report.read} records "
                    f"({report.skipped_unknown_label} unknown label, "
                    f"{report.skipped_spam} spam, {report.skipped_unlabelled} unlabelled, "
                    f"{report.skipped_unparseable} unparseable)",
                    "Inspect the skipped rows. Unknown label spellings are refused rather "
                    "than guessed; spam rows need --spam-as phish|ham if you want them.",
                )
            )
        if report.unknown_label_values:
            top = ", ".join(
                f"'{k}' x{v}"
                for k, v in sorted(report.unknown_label_values.items(), key=lambda kv: -kv[1])[:5]
            )
            audit.findings.append(
                Finding(
                    "warn",
                    f"unrecognised labels in {spec}",
                    top,
                    "Relabel these values in the file, or tell the loader what they mean.",
                )
            )
        if report.decode_replacements > max(50, report.kept):
            audit.findings.append(
                Finding(
                    "warn",
                    f"text decoding in {spec}",
                    f"{report.decode_replacements} undecodable characters remained after "
                    "trying the declared charset, UTF-8 and windows-1252",
                    "Usually harmless in small amounts; a very high count means a charset "
                    "the loader cannot identify.",
                )
            )

    audit.n = len(messages)
    audit.n_phish = int(sum(labels))
    audit.n_ham = audit.n - audit.n_phish
    if not messages:
        audit.findings.append(Finding("fail", "corpus", "no messages loaded", ""))
        return audit, messages, labels

    y = np.asarray(labels, dtype=int)

    # ---------------------------------------------------------- balance
    if audit.n_phish == 0 or audit.n_ham == 0:
        audit.findings.append(
            Finding(
                "fail",
                "class balance",
                f"{audit.n_phish} phishing and {audit.n_ham} legitimate messages - a "
                "detector needs both",
                "Pair a phishing corpus (e.g. Nazario#phish) with a legitimate one "
                "(e.g. an Enron maildir#ham).",
            )
        )
        return audit, messages, labels
    ratio = audit.n_phish / audit.n
    if ratio < 0.05 or ratio > 0.95:
        audit.findings.append(
            Finding(
                "warn",
                "class balance",
                f"phishing is {ratio:.1%} of the corpus",
                "Extremely imbalanced training data makes the minority class hard to "
                "learn; subsample the majority with --limit.",
            )
        )
    else:
        audit.findings.append(
            Finding("ok", "class balance", f"phishing is {ratio:.1%} of the corpus")
        )

    # ------------------------------------------------------- coverage
    n = audit.n
    audit.coverage = {
        "behavioural_context": sum(1 for m in messages if m.behavioral.available) / n,
        "auth_verdicts": sum(
            1
            for m in messages
            if m.auth.spf != "none" or m.auth.dkim != "none" or m.auth.dmarc != "none"
        )
        / n,
        "dated": sum(1 for m in messages if m.received_at != UNDATED) / n,
        "has_url": sum(1 for m in messages if "http" in (m.body + m.html_body).lower()) / n,
        "has_html": sum(1 for m in messages if m.html_body) / n,
        "has_sender": sum(1 for m in messages if m.sender_address) / n,
    }
    audit.coverage = {k: round(v, 4) for k, v in audit.coverage.items()}
    if audit.coverage["behavioural_context"] == 0:
        audit.findings.append(
            Finding(
                "warn",
                "behavioural context",
                "no message carries gateway history (sender relationship, burst, domain "
                "age). Public corpora never do.",
                "Expected. The system runs on email and URL evidence only and records "
                "that it did; quote results as 'email + URL', not tri-modal.",
            )
        )

    # ------------------------------------------------------ duplicates
    prints = [m.fingerprint() for m in messages]
    counts = Counter(prints)
    exact_dupes = sum(c - 1 for c in counts.values() if c > 1)
    by_print: dict[str, set[int]] = {}
    for p_, lab in zip(prints, y, strict=False):
        by_print.setdefault(p_, set()).add(int(lab))
    conflicting = sum(1 for labs in by_print.values() if len(labs) > 1)
    audit.duplicates = {"exact_duplicates": exact_dupes, "same_message_both_labels": conflicting}
    if conflicting:
        audit.findings.append(
            Finding(
                "fail",
                "label noise",
                f"{conflicting} distinct messages appear with BOTH labels",
                "Remove them before training; a message cannot be both phishing and "
                "legitimate, and the model will learn noise.",
            )
        )
    if exact_dupes > 0.05 * n:
        audit.findings.append(
            Finding(
                "warn",
                "duplicates",
                f"{exact_dupes} exact duplicates ({exact_dupes / n:.1%})",
                "The grouped split keeps duplicates on one side, but they still inflate "
                "the class they belong to. Consider deduplicating.",
            )
        )
    # Near-duplicates across the label boundary: the subtlest form of noise.
    phish = [m for m, lab in zip(messages, y, strict=False) if lab == 1][:3000]
    ham = [m for m, lab in zip(messages, y, strict=False) if lab == 0][:3000]
    cross_near = len(find_near_duplicates(phish, ham, threshold=near_duplicate_threshold))
    audit.duplicates["near_duplicates_across_labels"] = cross_near
    if cross_near > 0.01 * min(len(phish), len(ham)):
        audit.findings.append(
            Finding(
                "warn",
                "near-duplicates across labels",
                f"{cross_near} legitimate messages are near-copies of a phishing message",
                "Often a phishing kit copying a real template - which is realistic and "
                "worth keeping - but check they are not mislabelled copies.",
            )
        )

    # --------------------------------------------------------- confounds
    for name, values in _metadata_features(messages).items():
        if np.all(values == values[0]):
            continue
        auc = single_feature_auc(values, y)
        row = {"feature": name, "auc": round(auc, 4)}
        audit.confounds.append(row)
    audit.confounds.sort(key=lambda r: -r["auc"])
    for row in audit.confounds:
        if row["auc"] >= CONFOUND_SEVERE:
            audit.findings.append(
                Finding(
                    "fail",
                    f"confound: {row['feature']}",
                    f"'{row['feature']}' alone predicts the label with AUC {row['auc']:.3f}. "
                    "This carries no phishing meaning, so the classes differ in how they "
                    "were captured, not only in what they are.",
                    _confound_fix(row["feature"]),
                )
            )
        elif row["auc"] >= CONFOUND_WARN:
            audit.findings.append(
                Finding(
                    "warn",
                    f"confound: {row['feature']}",
                    f"'{row['feature']}' alone predicts the label with AUC {row['auc']:.3f}.",
                    _confound_fix(row["feature"]),
                )
            )

    # ------------------------------------------------------ era overlap
    def years_of(label: int) -> list[int]:
        return sorted(
            m.received_at.year
            for m, lab in zip(messages, y, strict=False)
            if lab == label and m.received_at != UNDATED
        )

    yp, yh = years_of(1), years_of(0)
    if yp and yh:
        p_lo, p_hi = yp[int(0.05 * (len(yp) - 1))], yp[int(0.95 * (len(yp) - 1))]
        h_lo, h_hi = yh[int(0.05 * (len(yh) - 1))], yh[int(0.95 * (len(yh) - 1))]
        overlap = max(0, min(p_hi, h_hi) - max(p_lo, h_lo) + 1)
        audit.year_range = {
            "phishing": [p_lo, p_hi],
            "legitimate": [h_lo, h_hi],
            "overlap_years": overlap,
        }
        if overlap == 0:
            audit.findings.append(
                Finding(
                    "fail",
                    "era mismatch",
                    f"phishing spans {p_lo}-{p_hi}, legitimate mail {h_lo}-{h_hi}: the "
                    "classes never overlap in time.",
                    "Use phishing and legitimate mail from the same years - e.g. restrict "
                    "Nazario to its oldest files for Enron/SpamAssassin ham, or pair recent "
                    "Nazario years with recent legitimate mail - and evaluate with "
                    "--split temporal.",
                )
            )
    return audit, messages, labels


def _confound_fix(feature: str) -> str:
    return {
        "receipt year": "Match the eras of the two classes, or drop date-derived "
        "signals and evaluate with --split temporal.",
        "is undated": "One source lacks Date headers; check the loader report for that source.",
        "has any auth verdict": "Authentication headers depend on when and where mail was "
        "captured. Retrain with auth features ignored, or use "
        "same-era, same-gateway sources.",
        "has a DMARC verdict": "DMARC dates from 2012; pre-2012 legitimate mail cannot carry "
        "it. Match eras before trusting any auth-based result.",
        "Received-hop count": "Different capture points record different relay chains; "
        "treat hop count as unreliable on this corpus.",
        "has an HTML part": "One source was stored as plain text only. Compare "
        "results with and without the HTML-derived features.",
        "recipient count": "One source stripped or anonymised To: headers.",
        "has Return-Path": "One source stripped envelope headers during collection.",
    }.get(feature, "Check how each source was collected.")


def render_audit(audit: CorpusAudit) -> str:
    lines = [f"corpus audit: {audit.verdict}", ""]
    lines.append(f"  messages      {audit.n}  ({audit.n_phish} phishing, {audit.n_ham} legitimate)")
    for src in audit.sources:
        lines.append(
            f"  - {src['spec']}: kept {src['kept']}/{src['read']}  "
            f"[{src['label_convention']}]"
            + (
                f"  html-only converted {src['html_only_converted']}"
                if src["html_only_converted"]
                else ""
            )
            + (f"  encoded subjects {src['encoded_subjects']}" if src["encoded_subjects"] else "")
        )
    if audit.coverage:
        c = audit.coverage
        lines.append(
            f"\n  coverage      auth verdicts {c['auth_verdicts']:.0%} · dated {c['dated']:.0%} · "
            f"URLs {c['has_url']:.0%} · HTML {c['has_html']:.0%} · "
            f"behavioural context {c['behavioural_context']:.0%}"
        )
    if audit.year_range:
        yr = audit.year_range
        lines.append(
            f"  years         phishing {yr['phishing'][0]}-{yr['phishing'][1]} · "
            f"legitimate {yr['legitimate'][0]}-{yr['legitimate'][1]} "
            f"(overlap {yr['overlap_years']} yr)"
        )
    if audit.confounds:
        lines.append("\n  confound audit (metadata that should NOT predict the label):")
        for row in audit.confounds:
            flag = (
                "  !!"
                if row["auc"] >= CONFOUND_SEVERE
                else ("  ! " if row["auc"] >= CONFOUND_WARN else "    ")
            )
            lines.append(f"  {flag} {row['feature']:22s} AUC {row['auc']:.3f}")
    lines.append("")
    for f in audit.findings:
        mark = {"ok": "[ OK ]", "warn": "[WARN]", "fail": "[FAIL]"}[f.level]
        lines.append(f"  {mark} {f.check}: {f.detail}")
        if f.fix and f.level != "ok":
            lines.append(f"         fix: {f.fix}")
    return "\n".join(lines)
