"""Corpus generation, public-corpus loading and leakage-safe splitting."""

from phishguard.data.splits import (
    LeakageReport,
    audit_leakage,
    grouped_split,
    temporal_split,
)
from phishguard.data.synthetic import CorpusGenerator, generate_corpus

__all__ = [
    "CorpusGenerator",
    "LeakageReport",
    "audit_leakage",
    "generate_corpus",
    "grouped_split",
    "temporal_split",
]
