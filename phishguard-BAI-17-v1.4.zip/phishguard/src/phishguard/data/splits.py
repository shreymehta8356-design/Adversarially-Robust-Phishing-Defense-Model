"""Leakage-safe splitting and the leakage audit.

A phishing corpus is *campaign-structured*: one kit generates hundreds of
near-identical messages. A random row-level split therefore puts siblings of a
test message in the training set and reports an accuracy that evaporates in
production. This module makes that failure mode impossible by construction and
then proves it with an audit.

Three guarantees
----------------
1. **Group disjointness.** Splits are made over ``group_key`` (campaign /
   thread), never over rows, so no campaign spans two splits.
2. **Near-duplicate separation.** Messages are shingled and hashed; any test
   message whose Jaccard similarity to a training message exceeds a threshold
   is dropped from the test set and counted.
3. **Feature-label sanity.** Every feature is scored for suspiciously high
   single-feature separability, which is how generator artefacts and
   accidentally-encoded labels get caught before they flatter the results.

A temporal split is also provided, because the honest question for a security
model is "does a model fitted on January hold up in June", not "can it
interpolate within a shuffled pool".
"""

from __future__ import annotations

import hashlib
import random
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from phishguard.schemas import EmailMessage

_SHINGLE_SIZE = 5
_MINHASH_PERMUTATIONS = 64


# --------------------------------------------------------------------------
# Near-duplicate detection (MinHash over character shingles)
# --------------------------------------------------------------------------
def _shingles(text: str, k: int = _SHINGLE_SIZE) -> set[str]:
    norm = " ".join((text or "").lower().split())
    if len(norm) <= k:
        return {norm} if norm else set()
    return {norm[i : i + k] for i in range(len(norm) - k + 1)}


def minhash_signature(text: str, n_perm: int = _MINHASH_PERMUTATIONS) -> tuple[int, ...]:
    """Order-independent sketch supporting fast Jaccard estimation."""
    shingles = _shingles(text)
    if not shingles:
        return tuple([0] * n_perm)
    hashed = np.array(
        [
            int.from_bytes(hashlib.blake2b(s.encode(), digest_size=8).digest(), "big")
            for s in shingles
        ],
        dtype=np.uint64,
    )
    rng = np.random.default_rng(12345)
    a = rng.integers(1, 2**61 - 1, size=n_perm, dtype=np.uint64)
    b = rng.integers(0, 2**61 - 1, size=n_perm, dtype=np.uint64)
    # (a*h + b) mod 2^61-1, vectorised over permutations x shingles
    mixed = (a[:, None] * hashed[None, :] + b[:, None]) % np.uint64(2**61 - 1)
    return tuple(int(v) for v in mixed.min(axis=1))


def jaccard_from_signatures(s1: tuple[int, ...], s2: tuple[int, ...]) -> float:
    if not s1 or not s2 or len(s1) != len(s2):
        return 0.0
    return sum(1 for x, y in zip(s1, s2, strict=True) if x == y) / len(s1)


def find_near_duplicates(
    reference: list[EmailMessage],
    candidates: list[EmailMessage],
    *,
    threshold: float = 0.85,
    n_perm: int = _MINHASH_PERMUTATIONS,
    bands: int = 16,
) -> set[int]:
    """Indices in ``candidates`` that are near-duplicates of ``reference``.

    Uses LSH banding so the comparison is near-linear rather than quadratic --
    a 12k x 12k exact comparison would dominate the training run.
    """
    if not reference or not candidates:
        return set()
    rows = max(n_perm // bands, 1)

    ref_sigs = [minhash_signature(m.text, n_perm) for m in reference]
    buckets: dict[tuple[int, bytes], list[int]] = {}
    for idx, sig in enumerate(ref_sigs):
        for b in range(bands):
            chunk = sig[b * rows : (b + 1) * rows]
            key = (b, hashlib.blake2b(repr(chunk).encode(), digest_size=8).digest())
            buckets.setdefault(key, []).append(idx)

    flagged: set[int] = set()
    for cidx, cand in enumerate(candidates):
        sig = minhash_signature(cand.text, n_perm)
        seen: set[int] = set()
        for b in range(bands):
            chunk = sig[b * rows : (b + 1) * rows]
            key = (b, hashlib.blake2b(repr(chunk).encode(), digest_size=8).digest())
            seen.update(buckets.get(key, ()))
        for ridx in seen:
            if jaccard_from_signatures(sig, ref_sigs[ridx]) >= threshold:
                flagged.add(cidx)
                break
    return flagged


# --------------------------------------------------------------------------
# Splitting
# --------------------------------------------------------------------------
@dataclass(slots=True)
class SplitResult:
    """A named split with the bookkeeping needed to defend it."""

    train_idx: list[int]
    test_idx: list[int]
    strategy: str
    dropped_near_duplicates: int = 0
    group_overlap: int = 0
    notes: dict[str, Any] = field(default_factory=dict)


def _group_keys(messages: list[EmailMessage]) -> list[str]:
    return [m.group_key or m.fingerprint() for m in messages]


def grouped_split(
    messages: list[EmailMessage],
    labels: list[int],
    *,
    test_size: float = 0.25,
    seed: int = 20260907,
    near_duplicate_threshold: float = 0.85,
    drop_near_duplicates: bool = True,
) -> SplitResult:
    """Stratified split over campaign groups, then near-duplicate scrubbing.

    Groups are bucketed by their majority label first so that the phishing rate
    is preserved in both halves; without that, group-level splitting can drift
    the class balance by several points on small corpora.
    """
    if len(messages) != len(labels):
        raise ValueError("messages and labels must be the same length")
    keys = _group_keys(messages)

    by_group: dict[str, list[int]] = {}
    for i, k in enumerate(keys):
        by_group.setdefault(k, []).append(i)

    phish_groups: list[str] = []
    ham_groups: list[str] = []
    for g, idxs in by_group.items():
        majority = sum(labels[i] for i in idxs) / len(idxs)
        (phish_groups if majority >= 0.5 else ham_groups).append(g)

    rng = random.Random(seed)  # noqa: S311 - reproducible split, not security
    rng.shuffle(phish_groups)
    rng.shuffle(ham_groups)

    # Stratify by MESSAGE count, not group count. Campaign sizes vary by more
    # than an order of magnitude (a targeted BEC is one message; a bulk lure is
    # forty), so taking 25% of the groups in each class can easily hand the test
    # set a class balance ten points away from training. Greedily fill each
    # class's test quota by message count instead.
    test_groups: set[str] = set()
    for bucket in (phish_groups, ham_groups):
        target = sum(len(by_group[g]) for g in bucket) * test_size
        taken = 0
        for g in bucket:
            size = len(by_group[g])
            if taken >= target:
                break
            # Stop *before* a group that would overshoot the quota by more than
            # half its own size; large campaigns otherwise drag the test-set
            # class balance several points away from training.
            if taken + size > target and (taken + size - target) > size / 2:
                continue
            test_groups.add(g)
            taken += size

    train_idx = [i for i, k in enumerate(keys) if k not in test_groups]
    test_idx = [i for i, k in enumerate(keys) if k in test_groups]

    dropped = 0
    if drop_near_duplicates and train_idx and test_idx:
        flagged = find_near_duplicates(
            [messages[i] for i in train_idx],
            [messages[i] for i in test_idx],
            threshold=near_duplicate_threshold,
        )
        if flagged:
            dropped = len(flagged)
            test_idx = [t for j, t in enumerate(test_idx) if j not in flagged]

    overlap = len({keys[i] for i in train_idx} & {keys[i] for i in test_idx})
    return SplitResult(
        train_idx=train_idx,
        test_idx=test_idx,
        strategy="grouped-stratified",
        dropped_near_duplicates=dropped,
        group_overlap=overlap,
        notes={
            "n_groups": len(by_group),
            "n_test_groups": len(test_groups),
            "train_phish_rate": _rate(labels, train_idx),
            "test_phish_rate": _rate(labels, test_idx),
        },
    )


def temporal_split(
    messages: list[EmailMessage],
    labels: list[int],
    *,
    test_size: float = 0.25,
    near_duplicate_threshold: float = 0.85,
    drop_near_duplicates: bool = True,
) -> SplitResult:
    """Train on the past, test on the future.

    This is the split that answers the operational question, and it is
    routinely 3-8 F1 points harsher than a random split because campaign
    vocabulary drifts. Both are reported in the evaluation dossier.
    """
    if len(messages) != len(labels):
        raise ValueError("messages and labels must be the same length")
    order = sorted(range(len(messages)), key=lambda i: messages[i].received_at)
    cut = int(len(order) * (1.0 - test_size))
    train_idx, test_idx = order[:cut], order[cut:]

    # A campaign straddling the cut point would still leak; move any group that
    # appears in training entirely out of the test set.
    keys = _group_keys(messages)
    train_groups = {keys[i] for i in train_idx}
    straddling = sum(1 for i in test_idx if keys[i] in train_groups)
    test_idx = [i for i in test_idx if keys[i] not in train_groups]

    dropped = 0
    if drop_near_duplicates and train_idx and test_idx:
        flagged = find_near_duplicates(
            [messages[i] for i in train_idx],
            [messages[i] for i in test_idx],
            threshold=near_duplicate_threshold,
        )
        if flagged:
            dropped = len(flagged)
            test_idx = [t for j, t in enumerate(test_idx) if j not in flagged]

    return SplitResult(
        train_idx=train_idx,
        test_idx=test_idx,
        strategy="temporal",
        dropped_near_duplicates=dropped,
        group_overlap=0,
        notes={
            "cut_at": messages[order[cut]].received_at.isoformat() if cut < len(order) else "",
            "straddling_groups_removed": straddling,
            "train_phish_rate": _rate(labels, train_idx),
            "test_phish_rate": _rate(labels, test_idx),
        },
    )


def _rate(labels: list[int], idx: list[int]) -> float:
    return round(sum(labels[i] for i in idx) / len(idx), 4) if idx else 0.0


# --------------------------------------------------------------------------
# Leakage audit
# --------------------------------------------------------------------------
@dataclass(slots=True)
class LeakageReport:
    """Machine-checkable evidence that the split is honest."""

    exact_duplicate_pairs: int
    near_duplicate_pairs: int
    group_overlap: int
    train_size: int
    test_size: int
    train_phish_rate: float
    test_phish_rate: float
    suspicious_features: list[dict[str, Any]] = field(default_factory=list)
    passed: bool = True
    failures: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "exact_duplicate_pairs": self.exact_duplicate_pairs,
            "near_duplicate_pairs": self.near_duplicate_pairs,
            "group_overlap": self.group_overlap,
            "train_size": self.train_size,
            "test_size": self.test_size,
            "train_phish_rate": self.train_phish_rate,
            "test_phish_rate": self.test_phish_rate,
            "suspicious_features": self.suspicious_features,
            "passed": self.passed,
            "failures": self.failures,
        }


def single_feature_auc(values: np.ndarray, labels: np.ndarray) -> float:
    """AUC of one feature used alone, via the rank-sum identity.

    A feature scoring above ~0.98 on its own is almost always an artefact
    (a leaked label, a generator tell) rather than a real signal.
    """
    pos = labels == 1
    n_pos, n_neg = int(pos.sum()), int((~pos).sum())
    if n_pos == 0 or n_neg == 0:
        return 0.5
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(len(values), dtype=np.float64)
    ranks[order] = np.arange(1, len(values) + 1, dtype=np.float64)
    # Average ranks within ties so constant features score exactly 0.5.
    sorted_vals = values[order]
    i = 0
    while i < len(sorted_vals):
        j = i
        while j + 1 < len(sorted_vals) and sorted_vals[j + 1] == sorted_vals[i]:
            j += 1
        if j > i:
            ranks[order[i : j + 1]] = (i + 1 + j + 1) / 2.0
        i = j + 1
    auc = (ranks[pos].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)
    return float(max(auc, 1.0 - auc))


def audit_leakage(
    messages: list[EmailMessage],
    labels: list[int],
    split: SplitResult,
    *,
    features: np.ndarray | None = None,
    feature_names: tuple[str, ...] | None = None,
    suspicious_auc: float = 0.985,
    max_class_imbalance_delta: float = 0.08,
) -> LeakageReport:
    """Run every leakage check and return a pass/fail report."""
    train_idx, test_idx = split.train_idx, split.test_idx
    keys = _group_keys(messages)

    train_fp = {messages[i].fingerprint() for i in train_idx}
    exact = sum(1 for i in test_idx if messages[i].fingerprint() in train_fp)

    near = 0
    if train_idx and test_idx:
        near = len(
            find_near_duplicates(
                [messages[i] for i in train_idx],
                [messages[i] for i in test_idx],
                threshold=0.85,
            )
        )

    overlap = len({keys[i] for i in train_idx} & {keys[i] for i in test_idx})
    tr_rate, te_rate = _rate(labels, train_idx), _rate(labels, test_idx)

    suspicious: list[dict[str, Any]] = []
    if features is not None and feature_names is not None and len(train_idx) > 20:
        y = np.asarray([labels[i] for i in train_idx], dtype=np.int64)
        X = features[train_idx]
        for j, name in enumerate(feature_names):
            auc = single_feature_auc(X[:, j], y)
            if auc >= suspicious_auc:
                suspicious.append({"feature": name, "single_feature_auc": round(auc, 4)})
        suspicious.sort(key=lambda d: -d["single_feature_auc"])

    failures: list[str] = []
    if exact:
        failures.append(f"{exact} exact duplicate message(s) span train and test")
    if near:
        failures.append(f"{near} near-duplicate message(s) span train and test")
    if overlap:
        failures.append(f"{overlap} campaign group(s) appear in both splits")
    if abs(tr_rate - te_rate) > max_class_imbalance_delta:
        failures.append(f"class balance drifted between splits ({tr_rate:.3f} vs {te_rate:.3f})")
    if suspicious:
        failures.append(
            f"{len(suspicious)} feature(s) separate the classes almost perfectly on their "
            f"own (top: {suspicious[0]['feature']} @ AUC {suspicious[0]['single_feature_auc']})"
        )

    return LeakageReport(
        exact_duplicate_pairs=exact,
        near_duplicate_pairs=near,
        group_overlap=overlap,
        train_size=len(train_idx),
        test_size=len(test_idx),
        train_phish_rate=tr_rate,
        test_phish_rate=te_rate,
        suspicious_features=suspicious[:10],
        passed=not failures,
        failures=failures,
    )
