"""Compositional sentence banks for the synthetic generator.

Templated corpora have a characteristic failure: two messages from *different*
campaigns end up 85%+ character-identical, which makes near-duplicate scrubbing
delete half the test set and makes the learning problem artificially easy.

The fix is to build messages compositionally rather than from fixed paragraphs.
A phishing body is assembled as::

    greeting + pretext + evidence + pressure + call-to-action + consequence + signoff

with each slot drawn independently from a bank of 6-10 phrasings. That yields
roughly 10^5 distinct bodies per lure type, which is the diversity a real
corpus has and a fixed template does not.

Slots use ``{url}``, ``{brand}``, ``{amount}``, ``{ref}``, ``{hours}``,
``{days}``, ``{name}``, ``{device}``, ``{city}`` placeholders.
"""

from __future__ import annotations

# --------------------------------------------------------------------------
# Phishing components
# --------------------------------------------------------------------------
PHISH_GREETINGS = [
    "Dear Customer,",
    "Dear User,",
    "Dear Valued Customer,",
    "Dear Account Holder,",
    "Dear Client,",
    "Hello,",
    "Attention:",
    "Dear Member,",
    "Dear Sir/Madam,",
    "Greetings,",
    "Dear {brand} User,",
]

PHISH_PRETEXTS = {
    "credential": [
        "Our security systems have flagged unusual sign-in activity on your {brand} account.",
        "We detected an attempt to access your {brand} account from an unrecognised device.",
        "Your {brand} account has been temporarily limited following a routine security review.",
        "During a scheduled audit we were unable to validate the information on your {brand} profile.",
        "A login was recorded from {city} on a device we do not recognise.",
        "Multiple failed authentication attempts have been logged against your {brand} account.",
        "Your account credentials appear in a recent third-party data exposure.",
    ],
    "bank": [
        "A transfer of {amount} has been initiated from your account and is awaiting authorisation.",
        "Your net banking access has been placed on hold pending mandatory KYC re-verification.",
        "We were unable to complete the periodic verification of your registered details.",
        "A new beneficiary was added to your account from an unregistered device.",
        "Your debit card has been temporarily deactivated after an unusual transaction of {amount}.",
        "Regulatory guidelines require an immediate re-confirmation of your account information.",
    ],
    "package": [
        "Your parcel {ref} is being held at our sorting facility.",
        "We attempted delivery of shipment {ref} but nobody was available to receive it.",
        "Customs has placed shipment {ref} on hold pending payment of an import charge of {amount}.",
        "The delivery address supplied for parcel {ref} appears to be incomplete.",
        "Your package could not be released because the handling fee of {amount} is outstanding.",
    ],
    "prize": [
        "Your email address was selected in this quarter's customer appreciation draw.",
        "You have been chosen as one of {days} winners in our anniversary promotion.",
        "A reward of {amount} has been allocated to your account and is awaiting collection.",
        "Congratulations - your account qualified for our loyalty bonus of {amount}.",
    ],
    "crypto": [
        "A withdrawal request of {amount} is pending on your wallet.",
        "Your wallet has been flagged by our compliance system and access is restricted.",
        "We detected an unauthorised device attempting to sign transactions on your wallet.",
        "Your recovery phrase must be re-validated following a protocol upgrade.",
    ],
    "invoice_fraud": [
        "Invoice {ref} remains unpaid and is now {days} days overdue.",
        "Our records show an outstanding balance of {amount} against invoice {ref}.",
        "Payment for invoice {ref} was not received by the agreed date.",
        "The account statement attached shows {amount} outstanding on your account.",
    ],
    "subscription": [
        "We were unable to process the payment for your {brand} subscription.",
        "Your {brand} membership will lapse because the card on file was declined.",
        "The last billing attempt on your {brand} plan failed.",
        "Your {brand} subscription is on hold following a failed payment of {amount}.",
    ],
    "storage_full": [
        "Your mailbox has exceeded its allocated storage quota.",
        "Incoming messages to your mailbox are currently being rejected by the server.",
        "{days} messages addressed to you are being held because your mailbox is full.",
        "A mailbox migration requires you to re-authenticate before delivery resumes.",
    ],
    "tax_refund": [
        "Following the annual assessment of your filings you are eligible for a refund of {amount}.",
        "A refund of {amount} has been approved against your tax account.",
        "Our calculation shows an overpayment of {amount} on your account for the last period.",
        "Your refund claim reference {ref} has been processed and is ready for disbursement.",
    ],
    "sextortion": [
        "Monitoring software was installed on your device some time ago.",
        "I have had access to your device and accounts for several weeks.",
        "Your device was compromised through a vulnerability in software you use daily.",
    ],
}

PHISH_EVIDENCE = [
    "Reference: {ref}",
    "Case ID: {ref}",
    "Incident reference {ref} was raised at {hours}:00 today.",
    "The activity was logged from {city} on a {device} device.",
    "Device: {device}    Location: {city}",
    "Our records list the transaction reference as {ref}.",
    "",
    "",
]

PHISH_PRESSURE = [
    "This must be completed within {hours} hours.",
    "You have {hours} hours to respond before the restriction becomes permanent.",
    "Action is required today to avoid interruption.",
    "Failure to respond within {days} days will result in closure.",
    "This is the final notice regarding this matter.",
    "Delays beyond {hours} hours cannot be reversed by our support team.",
    "Please treat this as urgent.",
    "Immediate attention is required.",
]

PHISH_CTA = [
    "Verify your details here: {url}",
    "Confirm your identity: {url}",
    "Complete the verification: {url}",
    "Restore access to your account: {url}",
    "Update your information now: {url}",
    "Click below to resolve this: {url}",
    "Review and confirm: {url}",
    "Secure your account: {url}",
    "Proceed to the secure portal: {url}",
    "Follow this link to continue: {url}",
]

PHISH_CONSEQUENCE = [
    "Accounts that are not verified will be permanently suspended.",
    "Unverified accounts are closed and the associated data is deleted.",
    "Your access will remain restricted until this is completed.",
    "Further transactions will be declined until verification is complete.",
    "Legal recovery action may follow if this remains unresolved.",
    "We will be unable to restore your account after the deadline.",
    "",
]

PHISH_SIGNOFF = [
    "{brand} Security Team",
    "{brand} Customer Support",
    "Account Security Department",
    "Compliance and Verification Unit",
    "Customer Service",
    "The {brand} Team",
    "Automated Security Notification - do not reply",
    "Support Desk",
]

# --------------------------------------------------------------------------
# Hard phishing (fluent, low pressure)
# --------------------------------------------------------------------------
BEC_OPENERS = [
    "Are you at your desk?",
    "Quick one for you.",
    "Do you have a minute?",
    "Are you free this afternoon?",
    "Hope the week is going alright.",
    "Sorry to drop this on you.",
    "Can you help me with something?",
]
BEC_BODIES = [
    "I need something handled before the board call and I'm in meetings all day.",
    "There's a payment that has to go out today and I can't get to a laptop.",
    "I need you to look after a supplier matter while I'm travelling.",
    "Something came up with one of the accounts and I'd rather not put it in writing yet.",
    "I need a quick favour that I'd rather keep off the group thread for now.",
]
BEC_CLOSERS = [
    "Let me know when you have a moment and I'll send the details.",
    "Reply here when you get this and I'll explain.",
    "Just confirm you've seen this and I'll follow up.",
    "Drop me a line when you're free.",
]
BEC_SIGNOFFS = [
    "Sent from my phone",
    "Sent from my iPhone",
    "Regards",
    "Thanks",
    "",
]

HIJACK_LINES = [
    "Thanks - see the updated version, I've addressed the points you raised.",
    "Attaching the revised file, the numbers on page 3 are corrected now.",
    "Here's the latest draft with your comments folded in.",
    "Updated as discussed, let me know if anything else stands out.",
    "Sharing the final version ahead of tomorrow.",
]

# --------------------------------------------------------------------------
# Legitimate components
# --------------------------------------------------------------------------
HAM_OPENERS = [
    "Hi,",
    "Hello,",
    "Hi team,",
    "Morning,",
    "Hi {name},",
    "Hey,",
    "",
]
HAM_INTERNAL = [
    "Quick update on {topic}. The revised figures are in the shared folder.",
    "I've had a look at {topic} and left comments on the second section.",
    "Following up on {topic} - two of the assumptions need checking before Friday.",
    "Notes from this morning's discussion of {topic} are written up now.",
    "We closed out most of {topic} today; one item is still open.",
    "Short summary of where {topic} stands after this week.",
]
HAM_DETAIL = [
    "Nothing urgent - have a look when you get a chance.",
    "No action needed from you unless something looks off.",
    "I'll chase the outstanding item separately.",
    "Happy to walk through it if that's easier.",
    "The numbers are provisional until finance confirms.",
    "There's one open question about lead times from the Pune site.",
    "I've flagged the two line items we talked about.",
]
HAM_CLOSERS = [
    "Thanks,",
    "Cheers,",
    "Best,",
    "Regards,",
    "Thanks a lot,",
    "Kind regards,",
]

HAM_TRANSACTIONAL = [
    "This is an automated message and no action is required.",
    "You are receiving this because of activity on your account.",
    "Manage your notification preferences in your account settings.",
    "If you did not expect this message you can safely ignore it.",
    "Replies to this address are not monitored.",
    "You can unsubscribe from these updates at any time.",
]

#: Legitimate messages that hit phishing lexicons - the hard negatives.
HARD_HAM_BODIES = {
    "real_password_reset": [
        "We received a request to reset the password for your {brand} account.\n\n"
        "Reset it here: {url}\n\nThe link expires in 30 minutes. If you did not request "
        "this, no action is needed and your password will not change.",
        "Someone asked to reset your {brand} password. If it was you, use the link "
        "below within 30 minutes:\n\n{url}\n\nIf it wasn't you, you can ignore this "
        "message - nothing has changed on your account.",
        "A password reset was requested for your {brand} account from a {device} in "
        "{city}.\n\nContinue: {url}\n\nNot you? Ignore this email; the request expires "
        "on its own.",
    ],
    "real_security_alert": [
        "We noticed a new sign-in to your {brand} account.\n\nDevice: {device}\n"
        "Location: {city}\n\nIf this was you, there's nothing to do. If not, review "
        "recent activity here: {url}",
        "A new device signed in to your {brand} account from {city}.\n\nYou can see "
        "all active sessions in your security settings: {url}\n\nWe send this alert "
        "for every new device.",
        "Sign-in alert for your {brand} account\n\n{device} - {city} - {hours}:00\n\n"
        "Recognise it? No action needed. Don't? Review your sessions: {url}",
    ],
    "real_invoice": [
        "Dear Accounts Payable,\n\nPlease find attached invoice {ref} for services "
        "delivered last month, payable within 30 days to our usual account. "
        "Bank details are unchanged from the master agreement.\n\nIf payment has "
        "already been sent, please disregard this reminder.",
        "Hello,\n\nAttaching invoice {ref} ({amount}) for last month's work. Terms "
        "are the standard 30 days and our account details have not changed.\n\n"
        "Let me know if you need a PO reference adding.",
        "Hi,\n\nInvoice {ref} is attached. It covers the {days} consultancy days "
        "logged against the current statement of work. Payment details are as per "
        "the framework agreement.",
    ],
    "real_shipping": [
        "Your shipment {ref} is out for delivery today between {hours}:00 and "
        "{days}:00.\n\nTrack it: {url}\n\nNo action is required; if nobody is home "
        "the driver will leave a card.",
        "Parcel {ref} has left our {city} facility and is scheduled for delivery "
        "today.\n\nTracking: {url}\n\nDelivery windows are estimates and can shift "
        "by an hour or two.",
        "Update on shipment {ref}: it is now with the local delivery partner in "
        "{city}.\n\nFollow progress here: {url}",
    ],
    "real_mfa": [
        "Your verification code is {ref}.\n\nIt expires in 10 minutes. Do not share "
        "it with anyone - {brand} will never ask you for this code.\n\nDidn't try to "
        "sign in? Change your password at {url}.",
        "Use code {ref} to finish signing in to {brand}.\n\nThe code is valid for 10 "
        "minutes and can only be used once. If you did not request it, secure your "
        "account here: {url}",
    ],
    "real_expiry": [
        "Your annual {brand} plan renews on the {days}th and the card on file will "
        "be charged {amount}.\n\nUpdate billing or cancel renewal: {url}\n\n"
        "Questions? Reply to this email and a person will answer.",
        "Heads up - your {brand} subscription renews in a week at {amount}. "
        "Nothing to do if you're happy to continue.\n\nChange your plan: {url}",
    ],
    "real_tax": [
        "Your Form 16 for the financial year is now available on the employee "
        "portal.\n\nPlease download it before the filing deadline. Access the portal "
        "from your intranet bookmark - we never send direct login links by email.",
        "Payroll documents for the year have been published to the employee portal. "
        "Log in through the intranet as usual; this message contains no links by "
        "design.",
    ],
    # ---- patterns added after PG-HARD exposed them as blind spots ----------
    # Each of these is an ordinary, common shape of legitimate mail that the
    # first version of this generator never produced, which meant the model had
    # no way to learn that the shape is benign. They are realism fixes: the
    # phenomena are real, frequent, and were simply missing.
    "legit_esign": [
        "{name} has sent you a document for signature.\n\nReview and sign: {url}"
        "\n\nThis link is unique to you. Please do not forward this email - "
        "anyone holding the link can sign in your place.\n\nThe request expires "
        "in {days} days.",
        "A document is waiting for your signature from {name}.\n\nOpen it here: "
        "{url}\n\nThe link is personal to you and should not be shared. If you "
        "were not expecting this, you can decline from the same page.",
    ],
    "legit_rebrand": [
        "We are writing to let you know that {brand} now trades under a new "
        "name, and our billing domain has changed with it.\n\nPlease update "
        "your records before the next cycle so invoices are not delayed.\n\n"
        "New billing portal: {url}\n\nContract terms are unchanged.",
        "{brand} has completed its move to a new parent group. Invoices from "
        "the {days}th will come from this address instead of the old one.\n\n"
        "Account portal: {url}\n\nNothing else about your account changes, and "
        "your account manager is the same person.",
        "Our portal has moved to a new domain as part of the {brand} rebrand."
        "\n\nBookmark the new address: {url}\n\nThe old address will redirect "
        "for {days} days and then stop working.",
    ],
    "legit_list_mail": [
        "On the {days}th you wrote:\n> should this field stay nullable for the "
        "first leg?\n\nI would keep it non-null and use a sentinel instead. "
        "Nullable columns there have caused two outages already.\n\nDraft is in "
        "the archive: {url}",
        "Replying on list so the decision is recorded.\n\nWe agreed to keep "
        "{topic} as it is until the next review. Minutes and the thread so far "
        "are archived here: {url}\n\nHappy to reopen it if someone objects.",
        "> Has anyone hit this on the newer runtime?\n\nYes, and the fix is in "
        "the archive thread below. It needs a config change rather than a "
        "version bump.\n\n{url}",
    ],
}

#: Footers phishing kits copy verbatim from the brand they impersonate. Their
#: presence is why real phishing bodies are not reliably shorter than real mail
#: -- an early revision of this generator produced phish that were separable by
#: ``body_length`` alone at 0.95 AUC, which the leakage audit flagged.
PHISH_FOOTERS = [
    "\n\n---\nThis message was sent to you as part of our ongoing commitment to "
    "account security. Please do not reply to this address as the mailbox is "
    "not monitored. For assistance, contact our support team through the "
    "official channels listed in your account.",
    "\n\n---\nCONFIDENTIALITY NOTICE: This email and any attachments are "
    "confidential and intended solely for the addressee. If you have received "
    "this message in error please notify the sender and delete it from your "
    "system. Any unauthorised use, disclosure or copying is prohibited.",
    "\n\n---\nWhy did I receive this? You are receiving this notification "
    "because our records show an active account registered to this email "
    "address. Security notifications cannot be unsubscribed from.\n"
    "Registered office: 14 Barrington Court, Level 6.",
    "\n\n---\nPlease do not share your password, PIN or one-time code with "
    "anyone. Our staff will never ask you for these details over the phone or "
    "by email. Report suspicious messages to your local branch.",
    "",
    "",
    "",
]

#: Longer legitimate bodies, so that "short = suspicious" is not learnable.
HAM_LONG_TAIL = [
    "\n\nA couple of other things while I have you:\n\n"
    "- The vendor questionnaire came back, mostly fine, two clarifications needed\n"
    "- Finance want the cost centre split before they raise the PO\n"
    "- I've booked the room for the walkthrough, calendar invite to follow\n\n"
    "None of it is blocking, but the second item has a lead time so worth "
    "starting early.",
    "\n\nBackground for anyone new to the thread: we agreed in January to move "
    "the reconciliation off the nightly batch and onto the streaming pipeline. "
    "That work is mostly done; what's left is the historical backfill and the "
    "cutover plan. The backfill is the risky part because it touches live "
    "balances, so we want it done over a weekend with a rollback ready.",
    "\n\nOne more thing - the audit asked for evidence of the approval chain on "
    "changes like this. I've attached the signed-off change request from last "
    "quarter as an example of the format they want. Worth keeping the same "
    "shape so we don't have to redo it later.",
    "",
    "",
    "",
]

#: Legitimate mail whose *surface* looks like phishing: real marketing and
#: onboarding messages that use shorteners, urgency, new campaign subdomains and
#: "confirm your email" calls to action. Without these the model learns that a
#: shortener or a CTA is sufficient evidence, which is exactly the false-positive
#: behaviour that gets a filter switched off in production.
SUSPICIOUS_HAM_BODIES = [
    "Welcome aboard!\n\nYou're almost set up. Confirm your email address to "
    "activate your account:\n\n{url}\n\nThis link expires in 24 hours. If you "
    "didn't sign up, you can ignore this message.",
    "Your trial ends in {days} days.\n\nAfter that your workspace switches to "
    "read-only and exports are disabled. Add a payment method to keep "
    "everything running:\n\n{url}\n\nQuestions? Just reply.",
    "Last chance to claim your seat\n\nThe early-bird rate for the {city} "
    "workshop closes tonight and we're down to the final places.\n\n"
    "Reserve here: {url}\n\nAfter tonight the standard rate applies.",
    "Action needed: update your billing details\n\nThe card ending "
    "{ref} we have on file expires this month. Update it before the next cycle "
    "so your service isn't interrupted:\n\n{url}",
    "We've moved!\n\nOur portal has a new address. Please update your bookmark "
    "- the old link stops working on the {days}th.\n\nNew portal: {url}\n\n"
    "Your login details are unchanged.",
    "Your invoice {ref} for {amount} is ready\n\nView and pay online: {url}\n\n"
    "Payment is due within {days} days. Bank transfer details are on the "
    "invoice itself.",
    "Security update required\n\nWe're rolling out two-factor authentication "
    "across all accounts. Please enrol before the {days}th - accounts without "
    "2FA will be locked out until enrolment is complete.\n\nEnrol: {url}",
]

#: Subject lines matching the bodies above.
SUSPICIOUS_HAM_SUBJECTS = [
    "Confirm your email address",
    "Your trial ends in {days} days",
    "Last chance - {city} workshop",
    "Action needed: update your billing details",
    "Important: our portal has moved",
    "Invoice {ref} is ready",
    "Security update: enrol in two-factor authentication",
]

DEVICES = ["Windows", "macOS", "Android", "iPhone", "iPad", "Linux", "Chrome OS"]
CITIES = [
    "Mumbai, IN",
    "Pune, IN",
    "Bengaluru, IN",
    "Delhi, IN",
    "London, GB",
    "Berlin, DE",
    "Singapore, SG",
    "Lagos, NG",
    "Toronto, CA",
    "Dubai, AE",
    "Warsaw, PL",
    "Manila, PH",
    "Sao Paulo, BR",
    "Ho Chi Minh City, VN",
]
TOPICS = [
    "the Q3 supplier audit",
    "next week's sprint planning",
    "the warehouse layout change",
    "the vendor onboarding checklist",
    "Thursday's safety walkthrough",
    "the reconciliation report",
    "the staging backfill",
    "the partner API migration",
    "the annual insurance renewal",
    "the site survey findings",
]
