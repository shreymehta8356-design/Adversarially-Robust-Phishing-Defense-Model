"""Download public phishing and legitimate-mail corpora, with their terms and provenance.

Nothing in this project downloads data behind the user's back: this command
runs only when asked, prints each corpus's terms first, and refuses to proceed
until they are acknowledged with ``--accept-terms``. Files go to the data
folder, which ``.gitignore`` excludes -- several corpora contain real people's
mail and must never be committed or redistributed.

Every download is recorded in ``data/PROVENANCE.json`` with its source URL,
size, SHA-256 and time, so a result computed on it can name exactly which bytes
it came from. Archives are extracted defensively: a member with an absolute
path, a ``..`` component, a link or a device node is refused rather than
written, because an archive is untrusted input like any other.

The URLs below were checked against the maintainers' directory listings; if a
maintainer moves a file, the error message says which URL failed.
"""

from __future__ import annotations

import hashlib
import json
import tarfile
import time
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath
from typing import Any

NAZARIO = "https://monkey.org/~jose/phishing/"
SPAMASSASSIN = "https://spamassassin.apache.org/old/publiccorpus/"

NAZARIO_TERMS = (
    "Nazario phishing corpus (monkey.org/~jose/phishing). Real phishing mail sent to real "
    "recipients: treat it as personal data. Read README.txt and LICENSE.txt in the same "
    "directory before use; they set the terms of research use. Do not redistribute it or "
    "commit it to a repository."
)
SPAMASSASSIN_TERMS = (
    "SpamAssassin public corpus (spamassassin.apache.org/old/publiccorpus). Read readme.html "
    "in the same directory. The maintainers ask that these messages are never sent into a "
    "live mail system. The 'ham' folders are legitimate mail; the 'spam' folders are spam, "
    "not phishing."
)


@dataclass(frozen=True)
class Source:
    name: str
    url: str
    kind: str  # "mbox" or "tar.bz2"
    label: str  # "phish" or "ham"
    period: str
    terms: str
    #: Where the corpus lands inside the data folder (a file or a directory).
    target: str


SOURCES: dict[str, Source] = {
    s.name: s
    for s in (
        Source(
            "nazario-2025",
            NAZARIO + "phishing-2025",
            "mbox",
            "phish",
            "2025",
            NAZARIO_TERMS,
            "phishing-2025",
        ),
        Source(
            "nazario-2024",
            NAZARIO + "phishing-2024",
            "mbox",
            "phish",
            "2024",
            NAZARIO_TERMS,
            "phishing-2024",
        ),
        Source(
            "nazario-2023",
            NAZARIO + "phishing-2023",
            "mbox",
            "phish",
            "2023",
            NAZARIO_TERMS,
            "phishing-2023",
        ),
        Source(
            "nazario-2005",
            NAZARIO + "phishing0.mbox",
            "mbox",
            "phish",
            "2005",
            NAZARIO_TERMS,
            "phishing0.mbox",
        ),
        Source(
            "spamassassin-easy-ham",
            SPAMASSASSIN + "20030228_easy_ham.tar.bz2",
            "tar.bz2",
            "ham",
            "2002-2003",
            SPAMASSASSIN_TERMS,
            "easy_ham",
        ),
        Source(
            "spamassassin-easy-ham-2",
            SPAMASSASSIN + "20030228_easy_ham_2.tar.bz2",
            "tar.bz2",
            "ham",
            "2002-2003",
            SPAMASSASSIN_TERMS,
            "easy_ham_2",
        ),
        Source(
            "spamassassin-hard-ham",
            SPAMASSASSIN + "20030228_hard_ham.tar.bz2",
            "tar.bz2",
            "ham",
            "2002-2003",
            SPAMASSASSIN_TERMS,
            "hard_ham",
        ),
    )
}

MAX_BYTES = 200 * 2**20  # no public corpus here is anywhere near this


class TermsNotAccepted(RuntimeError):
    """The caller has not acknowledged the corpus terms."""


class UnsafeArchive(RuntimeError):
    """An archive member would escape the target folder or is not a plain file."""


def _check_url(url: str) -> None:
    parsed = urllib.parse.urlparse(url)
    local = parsed.hostname in {"127.0.0.1", "localhost"}
    if parsed.scheme != "https" and not (parsed.scheme == "http" and local):
        raise ValueError(f"refusing to download over {parsed.scheme or 'no scheme'}: {url}")


def download(
    url: str, dest: Path, *, timeout: float = 120.0, max_bytes: int = MAX_BYTES
) -> dict[str, Any]:
    """Stream ``url`` to ``dest``; return its size and SHA-256."""
    _check_url(url)
    dest.parent.mkdir(parents=True, exist_ok=True)
    partial = dest.with_suffix(dest.suffix + ".part")
    digest = hashlib.sha256()
    size = 0
    req = urllib.request.Request(  # noqa: S310 - scheme checked by _check_url above
        url, headers={"User-Agent": "phishguard-corpus-fetch/1.0"}
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp, partial.open("wb") as fh:  # noqa: S310 - scheme checked
            while chunk := resp.read(1 << 16):
                size += len(chunk)
                if size > max_bytes:
                    raise RuntimeError(f"{url} is larger than {max_bytes // 2**20} MB; refusing")
                digest.update(chunk)
                fh.write(chunk)
    except Exception:
        partial.unlink(missing_ok=True)
        raise
    partial.replace(dest)
    return {"bytes": size, "sha256": digest.hexdigest()}


def safe_extract(archive: Path, target_dir: Path) -> list[str]:
    """Extract a ``.tar.bz2`` refusing anything that is not a plain file or folder inside ``target_dir``."""
    target_dir.mkdir(parents=True, exist_ok=True)
    root = target_dir.resolve()
    written: list[str] = []
    with tarfile.open(archive, "r:bz2") as tar:
        members = tar.getmembers()
        for m in members:
            path = PurePosixPath(m.name)
            if path.is_absolute() or ".." in path.parts:
                raise UnsafeArchive(f"archive member escapes the target folder: {m.name!r}")
            if not (m.isfile() or m.isdir()):
                raise UnsafeArchive(f"archive member is not a plain file or folder: {m.name!r}")
            if not (root / m.name).resolve().is_relative_to(root):
                raise UnsafeArchive(f"archive member escapes the target folder: {m.name!r}")
        for m in members:
            destination = root / m.name
            if m.isdir():
                destination.mkdir(parents=True, exist_ok=True)
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            source = tar.extractfile(m)
            if source is None:
                continue
            with source, destination.open("wb") as fh:
                while chunk := source.read(1 << 16):
                    fh.write(chunk)
            written.append(m.name)
    return written


def fetch(
    names: list[str],
    data_dir: Path,
    *,
    accept_terms: bool = False,
    timeout: float = 120.0,
    sources: dict[str, Source] | None = None,
) -> list[dict[str, Any]]:
    """Download and unpack the named corpora into ``data_dir``; record provenance."""
    sources = sources or SOURCES
    unknown = [n for n in names if n not in sources]
    if unknown:
        raise KeyError(
            f"unknown corpus: {', '.join(unknown)} (see 'phishguard fetch-public --list')"
        )
    if not accept_terms:
        raise TermsNotAccepted("\n\n".join(sources[n].terms for n in names))
    records: list[dict[str, Any]] = []
    for name in names:
        src = sources[name]
        if src.kind == "mbox":
            meta = download(src.url, data_dir / src.target, timeout=timeout)
        else:
            archive = data_dir / Path(urllib.parse.urlparse(src.url).path).name
            meta = download(src.url, archive, timeout=timeout)
            files = safe_extract(archive, data_dir)
            meta["extracted_files"] = len(files)
            archive.unlink(missing_ok=True)
        records.append(
            {
                **asdict(src),
                **meta,
                "downloaded_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "terms_acknowledged": True,
                "data_source_spec": f"{(data_dir / src.target).as_posix()}#{src.label}",
            }
        )
    _append_provenance(data_dir, records)
    return records


def _append_provenance(data_dir: Path, records: list[dict[str, Any]]) -> Path:
    path = data_dir / "PROVENANCE.json"
    existing: list[dict[str, Any]] = []
    if path.exists():
        try:
            existing = json.loads(path.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            existing = []
    path.write_text(json.dumps(existing + records, indent=2), encoding="utf-8")
    return path
