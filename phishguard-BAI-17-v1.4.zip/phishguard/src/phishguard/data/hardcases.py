"""PG-HARD: a curated benchmark of deliberately difficult messages.

Why this file exists
--------------------
The synthetic corpus in :mod:`phishguard.data.synthetic` is *representative*:
it samples the whole distribution of mail a gateway sees, most of which is
easy. A detector scoring 0.999 macro-F1 on it has not proved very much, and an
examiner is right to say so. Aggregate accuracy on a representative corpus is
dominated by the easy majority and is therefore close to uninformative about
the cases that actually cost an organisation money.

PG-HARD is the opposite by construction. Every case in it is a message that a
naive detector gets *wrong for a specific, nameable reason*, and each case
records that reason. There is no easy mail here at all, so the score on this
set cannot be inflated by volume. It is a stress test, not a sample.

Two design commitments
----------------------
**1. Each case names the signal it defeats.** ``defeats`` says which
conventional cue is inverted -- "text content", "SMTP authentication",
"domain reputation", "sender history". A detector that leans on one cue fails
the whole family, which is exactly what the per-family table exposes.

**2. Grading is banded, not binary.** A three-band system (ALLOW / REVIEW /
BLOCK) is not trying to be certain about genuinely ambiguous mail -- that is
the point of having a middle band. Sending a hard case to a human is a
*correct* outcome, so each case declares ``tolerated`` bands and the headline
numbers are the two that represent real operational harm:

    silent delivery   a phish the user received with no warning  (ALLOW)
    false block       legitimate mail the user never saw         (BLOCK)

Grading binary accuracy at a fixed threshold would punish the abstention
band for doing its job, so the report carries both and leads with these.

Provenance
----------
Every case is hand-written from a documented real-world phishing or
false-positive pattern (see ``rationale``). No case is copied from a live
message: brands are referenced by name only, all domains are lookalikes or
``.example``, and no real recipient, URL path, token or account number
appears. Variants are deterministic substitutions over small pools, so the
benchmark is reproducible from the seed alone.
"""

from __future__ import annotations

import random
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from ..schemas import (
    BAND_ALLOW,
    BAND_BLOCK,
    BAND_REVIEW,
    Attachment,
    AuthResults,
    BehavioralContext,
    EmailMessage,
)

INTERNAL_DOMAIN = "northgate-industries.example"
BENCHMARK_ID = "PG-HARD-1"

#: Bands that count as an acceptable answer for each label. A hard positive
#: routed to REVIEW was caught; a hard negative routed to REVIEW costs an
#: analyst a glance. Only the remaining band is a true operational failure.
TOLERATED_PHISH = (BAND_BLOCK, BAND_REVIEW)
TOLERATED_HAM = (BAND_ALLOW, BAND_REVIEW)


# ---------------------------------------------------------------------------
# Substitution pools. Small, closed, and deliberately boring: the benchmark's
# difficulty must come from the case design, not from lexical novelty.
# ---------------------------------------------------------------------------
PEOPLE = (
    ("Priya Sharma", "priya.sharma"),
    ("Daniel Okafor", "daniel.okafor"),
    ("Meera Iyer", "meera.iyer"),
    ("Tom Brennan", "tom.brennan"),
    ("Anika Rao", "anika.rao"),
    ("Lucas Fernandes", "lucas.fernandes"),
)

SUPPLIERS = (
    ("Vantage Logistics", "vantage-logistics.example"),
    ("Meridian Packaging", "meridian-packaging.example"),
    ("Calder Freight", "calderfreight.example"),
    ("Ashgrove Components", "ashgrove-components.example"),
)

BANKS = (
    ("HDFC Bank", "hdfcbank.com", "hdfc"),
    ("Axis Bank", "axisbank.com", "axis"),
    ("Chase", "chase.com", "chase"),
    ("HSBC", "hsbc.com", "hsbc"),
)

CLOUD_BRANDS = (
    ("Microsoft 365", "microsoft.com", "Microsoft"),
    ("Google Workspace", "google.com", "Google"),
    ("Dropbox", "dropbox.com", "Dropbox"),
    ("Adobe Acrobat Sign", "adobe.com", "Adobe"),
)

#: Platforms that genuinely host user content, which is exactly why attackers
#: use them: the domain itself is reputable and cannot simply be blocklisted.
TRUSTED_HOSTS = (
    "forms.gle",
    "docs.google.com",
    "northgate-industries.sharepoint.com",
    "storage.googleapis.com",
    "notion.site",
    "firebaseapp.com",
)

#: Real ESP click-tracking shapes. Legitimate transactional mail routinely
#: arrives with a redirect through one of these, which defeats any rule of the
#: form "redirect through a third party implies phishing".
ESP_REDIRECTS = (
    "https://u2731456.ct.sendgrid.net/ls/click?upn={token}",
    "https://click.e.{brand}/?qs={token}",
    "https://links.mailchimp-proxy.example/track/click/{token}",
    "https://email.mg.{brand}/c/{token}",
)

TOKENS = (
    "8fj2kd91mzq0",
    "q71xbe4lm2",
    "kd82hslapq9",
    "3mzq08fj2k",
    "b4lm2q71xe",
    "slapq9kd82h",
    "zq08fj2kd9",
    "e4lm2q71xb",
)

AMOUNTS = ("2,480.00", "17,930.50", "864.20", "41,207.75", "6,115.00")
INVOICE_NOS = ("INV-44170", "INV-44182", "INV-44203", "INV-44219")
PO_NOS = ("PO-9921", "PO-9938", "PO-9947", "PO-9960")


@dataclass(slots=True)
class Variant:
    """One deterministic draw from the substitution pools."""

    rng: random.Random

    def person(self) -> tuple[str, str]:
        return self.rng.choice(PEOPLE)

    def supplier(self) -> tuple[str, str]:
        return self.rng.choice(SUPPLIERS)

    def bank(self) -> tuple[str, str, str]:
        return self.rng.choice(BANKS)

    def cloud(self) -> tuple[str, str, str]:
        return self.rng.choice(CLOUD_BRANDS)

    def token(self) -> str:
        return self.rng.choice(TOKENS)

    def host(self) -> str:
        return self.rng.choice(TRUSTED_HOSTS)

    def amount(self) -> str:
        return self.rng.choice(AMOUNTS)

    def invoice(self) -> str:
        return self.rng.choice(INVOICE_NOS)

    def po(self) -> str:
        return self.rng.choice(PO_NOS)

    def esp(self, brand_domain: str) -> str:
        return self.rng.choice(ESP_REDIRECTS).format(token=self.token(), brand=brand_domain)


@dataclass(slots=True)
class HardCase:
    """One difficulty pattern, plus a builder for concrete variants."""

    case_id: str
    label: int
    title: str
    #: The conventional cue this case inverts.
    defeats: str
    #: One or two sentences an examiner can read: why is this hard, and where
    #: does the pattern come from?
    rationale: str
    build: Callable[[Variant], EmailMessage]
    #: Bands that count as an acceptable answer. Defaults by label.
    tolerated: tuple[str, ...] = ()
    #: Grouping used for the per-family table in the report.
    family: str = ""

    def __post_init__(self) -> None:
        if not self.tolerated:
            object.__setattr__(
                self,
                "tolerated",
                TOLERATED_PHISH if self.label == 1 else TOLERATED_HAM,
            )
        if not self.family:
            object.__setattr__(self, "family", self.case_id.rsplit("-", 1)[0])


# ---------------------------------------------------------------------------
# Small helpers so each case body stays readable
# ---------------------------------------------------------------------------
def _ctx(**kw: Any) -> BehavioralContext:
    """Behavioural context with sensible neutral defaults."""
    base: dict[str, Any] = {
        "available": True,
        "sender_first_seen": kw.get("prior", 0) == 0,
        "prior_messages_from_sender": 0,
        "prior_replies_to_sender": 0,
        "thread_depth": 0,
        "hour_local": 11,
        "is_weekend": False,
        "recipient_count": 1,
        "bcc_count": 0,
        "external_sender": True,
        "domain_report_count": 0,
        "domain_click_rate": 0.04,
        "burst_count_1h": 1,
        "display_name_alias_count": 1,
        "domain_age_days": 1500,
    }
    if "prior" in kw:
        base["prior_messages_from_sender"] = kw.pop("prior")
    base.update(kw)
    base["sender_first_seen"] = base["prior_messages_from_sender"] == 0
    return BehavioralContext(**base)


def _msg(
    *,
    subject: str,
    body: str,
    sender: str,
    auth: tuple[str, str, str],
    behavioral: BehavioralContext,
    reply_to: str = "",
    html_body: str = "",
    attachments: Iterable[Attachment] = (),
    hops: int = 3,
) -> EmailMessage:
    return EmailMessage(
        subject=subject,
        body=body,
        html_body=html_body,
        sender=sender,
        reply_to=reply_to,
        return_path=sender,
        to=[f"ops@{INTERNAL_DOMAIN}"],
        attachments=list(attachments),
        auth=AuthResults(*auth),
        behavioral=behavioral,
        received_hops=hops,
    )


PASS = ("pass", "pass", "pass")
PARTIAL = ("pass", "none", "none")
FORWARD_FAIL = ("fail", "fail", "fail")


# ===========================================================================
# HARD NEGATIVES -- legitimate mail that trips naive detectors
# ===========================================================================
def _hn_esp_redirect(v: Variant) -> EmailMessage:
    name, domain, brand = v.cloud()
    link = v.esp(domain)
    return _msg(
        subject=f"Your {name} sign-in code",
        body=(
            f"Hello,\n\nUse this link to finish signing in to {name}. "
            "It expires in 10 minutes and can be used once.\n\n"
            f"{link}\n\n"
            "If you did not try to sign in you can ignore this message.\n\n"
            f"The {brand} account team"
        ),
        sender=f"{brand} <no-reply@{domain}>",
        auth=PASS,
        behavioral=_ctx(prior=41, domain_age_days=9200, domain_click_rate=0.31),
    )


def _hn_rebrand(v: Variant) -> EmailMessage:
    name, _old = v.supplier()
    short = name.split()[0].lower()
    new_domain = f"{short}-group.example"
    return _msg(
        subject="Important: our billing address has changed",
        body=(
            f"Dear customer,\n\n{name} is now trading as {name} Group. "
            "Please update your records before the next billing cycle so that "
            "invoices are not delayed.\n\n"
            f"Our new billing portal: https://{new_domain}/billing\n\n"
            "Existing contract terms are unchanged. Contact your account "
            "manager if you have questions.\n\n"
            "Accounts team"
        ),
        sender=f"{name} Group <billing@{new_domain}>",
        auth=PASS,
        behavioral=_ctx(prior=0, domain_age_days=22, recipient_count=340, burst_count_1h=310),
    )


def _hn_it_reauth(v: Variant) -> EmailMessage:
    name, local = v.person()
    return _msg(
        subject="Action required: re-enrol your MFA device by Friday",
        body=(
            "All staff,\n\nWe are migrating multi-factor authentication to the "
            "new provider this week. You must re-enrol your device before "
            "Friday 17:00 or you will lose access to email and the VPN.\n\n"
            f"Re-enrol here: https://mfa.{INTERNAL_DOMAIN}/enrol\n\n"
            "This takes about two minutes. The service desk can help if your "
            "phone has changed.\n\n"
            f"{name}\nIT Service Desk"
        ),
        sender=f"IT Service Desk <{local}@{INTERNAL_DOMAIN}>",
        auth=PASS,
        behavioral=_ctx(
            prior=63,
            external_sender=False,
            recipient_count=480,
            burst_count_1h=470,
            domain_age_days=4100,
        ),
    )


def _hn_new_supplier_invoice(v: Variant) -> EmailMessage:
    name, domain = v.supplier()
    return _msg(
        subject=f"{v.invoice()} from {name}",
        body=(
            "Hello,\n\nPlease find attached our first invoice against "
            f"{v.po()}, due in 30 days.\n\n"
            f"Amount: {v.amount()}\n"
            "Payment details are on page 2 of the attachment. If anything "
            "looks wrong, reply to this message and we will reissue it.\n\n"
            f"Accounts Receivable\n{name}"
        ),
        sender=f"{name} Accounts <ar@{domain}>",
        auth=PASS,
        attachments=[Attachment(f"{v.invoice()}.pdf", "application/pdf", 184_320)],
        behavioral=_ctx(prior=0, domain_age_days=780),
    )


def _hn_esign(v: Variant) -> EmailMessage:
    name, domain, brand = v.cloud()
    signer, _ = v.person()
    return _msg(
        subject=f"{signer} sent you a document to sign",
        body=(
            f"{signer} has sent you a document for signature.\n\n"
            f"Review and sign: https://{domain}/documents/{v.token()}\n\n"
            "This link is unique to you. Do not forward this email; anyone "
            "with the link can sign on your behalf.\n\n"
            "Please complete within 7 days.\n\n"
            f"{brand} eSignature"
        ),
        sender=f"{brand} eSignature <no-reply@{domain}>",
        auth=PASS,
        behavioral=_ctx(prior=12, domain_age_days=9000, domain_click_rate=0.44),
    )


def _hn_recruiter(v: Variant) -> EmailMessage:
    name, local = v.person()
    return _msg(
        subject="Senior data engineer role - worth a conversation?",
        body=(
            "Hi,\n\nI came across your profile and thought of a senior data "
            "engineering role I am working on. It is hybrid, three days in "
            "office, and the team owns the whole pipeline.\n\n"
            f"Full description: https://boards.greenhouse-jobs.example/j/{v.token()}\n\n"
            "Happy to send the salary band if it is of interest. If not, no "
            "problem, and I will not follow up again.\n\n"
            f"{name}\nIndependent recruiter"
        ),
        sender=f"{name} <{local}.recruits@gmail.com>",
        auth=PARTIAL,
        behavioral=_ctx(prior=0, domain_age_days=9999, hour_local=8),
    )


def _hn_bank_alert_night(v: Variant) -> EmailMessage:
    bank, domain, _key = v.bank()
    return _msg(
        subject=f"{bank}: did you authorise this transaction?",
        body=(
            f"We have blocked a card transaction of {v.amount()} because it "
            "does not match your usual pattern.\n\n"
            "If this was you, confirm in the app and the payment will be "
            "released. If it was not you, your card is already frozen and no "
            "further action is needed.\n\n"
            f"Open the app or call the number on the back of your card.\n\n"
            f"{bank} Fraud Operations"
        ),
        sender=f"{bank} Alerts <alerts@{domain}>",
        auth=PASS,
        behavioral=_ctx(prior=27, hour_local=3, domain_age_days=8600),
    )


def _hn_shortlink(v: Variant) -> EmailMessage:
    name, local = v.person()
    return _msg(
        subject="Re: deck for Thursday",
        body=(
            "Here is the version I mentioned, the slide order changed after "
            "the review.\n\n"
            f"https://bit.ly/{v.token()[:7]}\n\n"
            f"Shout if the numbers on slide 6 look off to you.\n\n{name}"
        ),
        sender=f"{name} <{local}@{INTERNAL_DOMAIN}>",
        auth=PASS,
        behavioral=_ctx(
            prior=210,
            prior_replies_to_sender=88,
            thread_depth=4,
            external_sender=False,
            domain_age_days=4100,
        ),
    )


def _hn_newsletter(v: Variant) -> EmailMessage:
    links = "\n".join(f"https://news.industryweekly.example/a/{v.token()}" for _ in range(6))
    return _msg(
        subject="Last chance: early-bird pricing ends tonight",
        body=(
            "This week in logistics\n\n"
            "Early-bird tickets close at midnight. After that the rate goes "
            "up by 40 percent, so book now if you are coming.\n\n"
            f"{links}\n\n"
            "You are receiving this because you subscribed at a trade show.\n"
            "Unsubscribe: https://news.industryweekly.example/unsubscribe\n"
            "Industry Weekly, 4 Harbour Road"
        ),
        sender="Industry Weekly <news@industryweekly.example>",
        auth=PASS,
        behavioral=_ctx(
            prior=31,
            recipient_count=14_000,
            burst_count_1h=9800,
            domain_age_days=2600,
            domain_click_rate=0.09,
        ),
    )


def _hn_mailinglist_dmarc(v: Variant) -> EmailMessage:
    name, local = v.person()
    return _msg(
        subject="Re: [logistics-wg] draft schema for shipment events",
        body=(
            "On Tuesday you wrote:\n"
            "> should carrier_id be nullable for first-mile legs?\n\n"
            "I would keep it non-null and use a sentinel carrier for "
            "first-mile. Nullable columns in that position have caused us two "
            "outages already.\n\n"
            "Draft is here if anyone wants to comment:\n"
            f"https://lists.logistics-wg.example/archive/{v.token()}\n\n"
            f"{name}"
        ),
        sender=f"{name} via logistics-wg <logistics-wg@lists.logistics-wg.example>",
        reply_to=f"{local}@{INTERNAL_DOMAIN}",
        auth=FORWARD_FAIL,
        behavioral=_ctx(prior=140, thread_depth=6, recipient_count=210, domain_age_days=3400),
    )


def _hn_conference(v: Variant) -> EmailMessage:
    name, local = v.person()
    return _msg(
        subject="Invitation to review for ICLSC 2026",
        body=(
            f"Dear colleague,\n\nWe are inviting you to join the programme "
            "committee for ICLSC 2026. The commitment is four papers in "
            "February.\n\n"
            f"Accept or decline here: https://iclsc2026.example/pc/{v.token()}\n\n"
            "Please respond within 14 days so we can finalise the committee.\n\n"
            f"{name}\nProgramme Chair, ICLSC 2026"
        ),
        sender="ICLSC 2026 <chairs@iclsc2026.example>",
        auth=PARTIAL,
        behavioral=_ctx(prior=0, domain_age_days=95, recipient_count=1),
    )


def _hn_real_reset(v: Variant) -> EmailMessage:
    bank, domain, _key = v.bank()
    return _msg(
        subject=f"Reset your {bank} password",
        body=(
            f"We received a request to reset the password on your {bank} "
            "account.\n\n"
            f"Reset it here: https://www.{domain}/account/reset?token={v.token()}\n\n"
            "The link expires in 30 minutes. If you did not request this, no "
            "action is needed and your password will not change.\n\n"
            f"https://www.{domain}/privacy\n"
            f"https://www.{domain}/contact"
        ),
        sender=f"{bank} <no-reply@{domain}>",
        auth=PASS,
        behavioral=_ctx(prior=9, domain_age_days=8600, hour_local=16),
    )


# ===========================================================================
# HARD POSITIVES -- phishing that looks legitimate
# ===========================================================================
def _hp_clone_auth_pass(v: Variant) -> EmailMessage:
    bank, domain, key = v.bank()
    look = f"{key}-secure-mail.example"
    return _msg(
        subject=f"Reset your {bank} password",
        body=(
            f"We received a request to reset the password on your {bank} "
            "account.\n\n"
            f"Reset it here: https://{look}/account/reset?token={v.token()}\n\n"
            "The link expires in 30 minutes. If you did not request this, no "
            "action is needed and your password will not change.\n\n"
            f"https://www.{domain}/privacy\n"
            f"https://www.{domain}/contact"
        ),
        sender=f"{bank} <no-reply@{look}>",
        auth=PASS,
        behavioral=_ctx(
            prior=0,
            domain_age_days=41,
            burst_count_1h=34,
            hour_local=14,
            display_name_alias_count=2,
        ),
    )


def _hp_bec_nolink(v: Variant) -> EmailMessage:
    name, local = v.person()
    return _msg(
        subject="Quick one",
        body=(
            "Are you at your desk?\n\n"
            "I need a supplier payment moved today and I am about to go into "
            "a meeting. Let me know when you have a minute and I will send "
            "the details across.\n\n"
            f"{name}\nSent from my phone"
        ),
        sender=f"{name} <{local}@northgate-industrles.example>",
        reply_to=f"{local}.finance@gmail.com",
        auth=PASS,
        behavioral=_ctx(prior=0, domain_age_days=17, hour_local=10, display_name_alias_count=3),
    )


def _hp_compromised_internal(v: Variant) -> EmailMessage:
    name, local = v.person()
    return _msg(
        subject="Shared: Q3 headcount plan",
        body=(
            "Hi,\n\nSharing the headcount plan ahead of Monday. You will need "
            "to sign in with your work account to open it.\n\n"
            f"https://{v.host()}/d/{v.token()}\n\n"
            f"Thanks,\n{name}"
        ),
        sender=f"{name} <{local}@{INTERNAL_DOMAIN}>",
        auth=PASS,
        behavioral=_ctx(
            prior=318,
            prior_replies_to_sender=96,
            external_sender=False,
            domain_age_days=4100,
            recipient_count=46,
            burst_count_1h=46,
        ),
    )


def _hp_trusted_host(v: Variant) -> EmailMessage:
    name, domain, brand = v.cloud()
    return _msg(
        subject=f"{brand}: storage quota exceeded",
        body=(
            "Your mailbox has reached its storage limit and new mail is being "
            "held.\n\n"
            f"Request additional storage: https://{v.host()}/forms/{v.token()}\n\n"
            "Held messages are released once the request is approved.\n\n"
            f"{brand} administration"
        ),
        sender=f"{brand} Admin <admin@{name.split()[0].lower()}-notices.example>",
        auth=PARTIAL,
        behavioral=_ctx(prior=0, domain_age_days=61, recipient_count=1, burst_count_1h=8),
    )


def _hp_open_redirect(v: Variant) -> EmailMessage:
    name, domain, brand = v.cloud()
    target = f"https://{brand.lower()}-verify-{v.token()[:5]}.example/login"
    return _msg(
        subject="Your document is ready to view",
        body=(
            "The document you requested is available for 24 hours.\n\n"
            f"View it: https://www.{domain}/url?q={target}\n\n"
            "After 24 hours you will need to request a new link.\n\n"
            f"{brand} Documents"
        ),
        sender=f"{brand} Documents <docs@{brand.lower()}-docs.example>",
        auth=PARTIAL,
        behavioral=_ctx(prior=0, domain_age_days=130, burst_count_1h=19),
    )


def _hp_aged_domain(v: Variant) -> EmailMessage:
    bank, _domain, key = v.bank()
    look = f"{key}-netbanking.example"
    return _msg(
        subject="Your account statement is ready",
        body=(
            "Your statement for this period is available in net banking.\n\n"
            f"View statement: https://{look}/statements/{v.token()}\n\n"
            "For your security the session will time out after 5 minutes of "
            "inactivity.\n\n"
            f"{bank}"
        ),
        sender=f"{bank} <statements@{look}>",
        auth=PASS,
        # The attacker bought a long-expired domain, so "new domain" fails.
        behavioral=_ctx(
            prior=0, domain_age_days=2140, burst_count_1h=6, display_name_alias_count=2
        ),
    )


def _hp_homoglyph(v: Variant) -> EmailMessage:
    bank, domain, _key = v.bank()
    # Latin 'l' for 'i' style substitution, plus a hyphenated subdomain.
    look = domain.replace("i", "l", 1).replace(".com", "-online.example")
    return _msg(
        subject="Unusual sign-in blocked",
        body=(
            "We blocked a sign-in to your account from a new device.\n\n"
            f"If this was not you, secure your account: https://{look}/secure/{v.token()}\n\n"
            "If it was you, no action is needed.\n\n"
            f"{bank} Security"
        ),
        sender=f"{bank} Security <security@{look}>",
        auth=PARTIAL,
        behavioral=_ctx(prior=0, domain_age_days=6, burst_count_1h=90, display_name_alias_count=4),
    )


def _hp_callback(v: Variant) -> EmailMessage:
    name, domain, brand = v.cloud()
    return _msg(
        subject="Subscription renewal confirmation",
        body=(
            f"Thank you for renewing {name} Premium.\n\n"
            f"Order reference: {v.invoice()}\n"
            f"Amount charged: {v.amount()}\n"
            "This amount will appear on your statement within 48 hours.\n\n"
            "Did not authorise this renewal? Our billing team can cancel it "
            "and refund the charge. Call +1 (888) 555-0164 within 24 hours; "
            "cancellations cannot be processed by email.\n\n"
            f"{brand} Billing"
        ),
        # No URL at all: every URL feature is zero by construction.
        sender=f"{brand} Billing <billing@{brand.lower()}-orders.example>",
        auth=PARTIAL,
        behavioral=_ctx(prior=0, domain_age_days=38, burst_count_1h=140),
    )


def _hp_thread_hijack(v: Variant) -> EmailMessage:
    name, local = v.person()
    supplier, sdomain = v.supplier()
    return _msg(
        subject=f"Re: {v.po()} - revised schedule",
        body=(
            "Apologies for the delay, revised dates attached in the portal "
            "below.\n\n"
            f"https://{sdomain.replace('.example', '-portal.example')}/docs/{v.token()}\n\n"
            "> On Tuesday you wrote:\n"
            f"> Can you confirm the delivery window for {v.po()}?\n"
            "> We need it before the yard closes on Friday.\n\n"
            f"{name}\n{supplier}"
        ),
        sender=f"{name} <{local}@{sdomain}>",
        auth=PASS,
        behavioral=_ctx(
            prior=54,
            prior_replies_to_sender=21,
            thread_depth=5,
            domain_age_days=1900,
            hour_local=15,
        ),
    )


def _hp_invoice_iban(v: Variant) -> EmailMessage:
    supplier, sdomain = v.supplier()
    name, local = v.person()
    return _msg(
        subject=f"{supplier}: updated remittance details for {v.invoice()}",
        body=(
            "Hello,\n\nPlease note our banking has moved to a new facility "
            "this quarter. Payments against open invoices should go to the "
            "account below from now on.\n\n"
            f"Invoice: {v.invoice()}\nAmount: {v.amount()}\n"
            "Account name: as before\n"
            "New account: ending 4417 (sort code on the attached remittance "
            "advice)\n\n"
            "Our old account will be closed at the end of the month, so any "
            "payment sent there will bounce back and delay the order.\n\n"
            f"{name}\nAccounts, {supplier}"
        ),
        sender=f"{name} <{local}@{sdomain}>",
        reply_to=f"{local}.accounts@{sdomain.replace('.example', '.co.example')}",
        auth=PASS,
        attachments=[Attachment("remittance-advice.pdf", "application/pdf", 96_240)],
        behavioral=_ctx(prior=47, thread_depth=0, domain_age_days=1900),
    )


def _hp_qr(v: Variant) -> EmailMessage:
    name, domain, brand = v.cloud()
    return _msg(
        subject="Your MFA enrolment expires today",
        body=(
            "Your multi-factor enrolment expires at the end of today.\n\n"
            "Scan the code below with your phone camera to re-enrol. The "
            "process takes under a minute.\n\n"
            "[QR code image]\n\n"
            "If the code does not scan, reply and we will arrange a manual "
            "reset.\n\n"
            "IT Security"
        ),
        html_body=(
            "<html><body><p>Your multi-factor enrolment expires today.</p>"
            '<img src="cid:qr-enrol-001" width="220" height="220" alt="">'
            "</body></html>"
        ),
        sender=f"IT Security <security@{INTERNAL_DOMAIN.replace('-', '')}.example>",
        auth=PARTIAL,
        behavioral=_ctx(
            prior=0,
            domain_age_days=11,
            recipient_count=210,
            burst_count_1h=200,
            display_name_alias_count=3,
        ),
    )


def _hp_slow_drip(v: Variant) -> EmailMessage:
    name, local = v.person()
    supplier, sdomain = v.supplier()
    return _msg(
        subject="contract wording",
        body=(
            "Hi,\n\nOur legal team marked up clause 7 of the framework "
            "agreement. Nothing controversial, mostly the notice period.\n\n"
            f"Markup is here: https://{sdomain.replace('.example', '-legal.example')}/share/{v.token()}\n\n"
            "No rush on this, some time next week is fine.\n\n"
            f"{name}"
        ),
        # No urgency, no threat, no credential language, one recipient, no
        # burst: every behavioural campaign signal is absent by design.
        sender=f"{name} <{local}@{sdomain.replace('.example', '-legal.example')}>",
        auth=PASS,
        behavioral=_ctx(
            prior=0,
            domain_age_days=410,
            recipient_count=1,
            burst_count_1h=1,
            hour_local=11,
            display_name_alias_count=1,
        ),
    )


# ===========================================================================
# The benchmark
# ===========================================================================
HARD_CASES: tuple[HardCase, ...] = (
    # ---------------------------------------------------------- negatives
    HardCase(
        "HN-ESP-REDIRECT",
        0,
        "Genuine sign-in code behind an ESP click-tracker",
        defeats="URL reputation",
        rationale=(
            "Real transactional mail is routinely sent through an email service "
            "provider whose click tracker rewrites every link, so the visible "
            "hostname does not match the brand. Any rule of the form 'redirect "
            "through a third-party domain implies phishing' fires on a large "
            "fraction of legitimate mail."
        ),
        build=_hn_esp_redirect,
    ),
    HardCase(
        "HN-REBRAND",
        0,
        "Legitimate supplier on a three-week-old domain",
        defeats="domain age",
        rationale=(
            "Domain age is one of the strongest single phishing signals, and it "
            "is wrong every time a real company rebrands, spins out, or "
            "registers a regional domain. Here a genuine supplier mails from a "
            "22-day-old domain about a billing change -- textually identical to "
            "invoice fraud."
        ),
        build=_hn_rebrand,
    ),
    HardCase(
        "HN-IT-REAUTH",
        0,
        "Real IT notice demanding MFA re-enrolment by Friday",
        defeats="text content",
        rationale=(
            "Genuine security administration mail uses exactly the vocabulary "
            "that phishing training tells users to distrust: a deadline, a "
            "consequence, and a link to authenticate. Content-only models "
            "cannot separate this from credential phishing because the content "
            "really is the same."
        ),
        build=_hn_it_reauth,
    ),
    HardCase(
        "HN-NEW-SUPPLIER",
        0,
        "First invoice from a genuine new supplier",
        defeats="sender history",
        rationale=(
            "Every real business relationship has a first message. Treating "
            "'no prior contact plus an invoice plus an attachment' as malicious "
            "blocks onboarding mail for every new supplier a company takes on."
        ),
        build=_hn_new_supplier_invoice,
    ),
    HardCase(
        "HN-ESIGN",
        0,
        "Genuine e-signature request with a unique token link",
        defeats="URL structure",
        rationale=(
            "E-signature notifications carry a long opaque single-use token in "
            "the path and warn the reader not to forward the mail -- the same "
            "shape and the same secrecy cue as a phishing link."
        ),
        build=_hn_esign,
    ),
    HardCase(
        "HN-RECRUITER",
        0,
        "Cold recruiter outreach from a free-mail address",
        defeats="sender reputation",
        rationale=(
            "Freemail plus no prior contact plus an external link is a classic "
            "phishing profile, and also describes most independent recruiters, "
            "freelancers and small consultancies."
        ),
        build=_hn_recruiter,
    ),
    HardCase(
        "HN-BANK-NIGHT",
        0,
        "Real bank fraud alert received at 03:00",
        defeats="behavioural timing",
        rationale=(
            "Off-hours delivery is a phishing signal, but fraud alerts are "
            "generated by the fraud itself, which happens at night precisely "
            "because it is night. The timing signal is inverted for exactly the "
            "messages that matter most to the user."
        ),
        build=_hn_bank_alert_night,
    ),
    HardCase(
        "HN-SHORTLINK",
        0,
        "Colleague sharing a bit.ly link in a live thread",
        defeats="URL reputation",
        rationale=(
            "Link shorteners hide the destination and are heavily abused, but "
            "they remain in ordinary internal use. Sender history and thread "
            "depth are the only things separating this from an attack."
        ),
        build=_hn_shortlink,
    ),
    HardCase(
        "HN-NEWSLETTER",
        0,
        "Marketing newsletter with deadline pressure",
        defeats="text content",
        rationale=(
            "Legitimate marketing is engineered to create urgency and to be "
            "clicked. 'Last chance', 'ends tonight' and a dozen tracked links "
            "are standard practice, not evidence of fraud."
        ),
        build=_hn_newsletter,
    ),
    HardCase(
        "HN-LIST-DMARC",
        0,
        "Mailing-list post that fails SPF, DKIM and DMARC",
        defeats="SMTP authentication",
        rationale=(
            "A mailing list rewrites the body and re-sends, which breaks DKIM "
            "and therefore DMARC for the original author. Authentication "
            "failure is a strong signal that is structurally guaranteed to be "
            "wrong for every discussion list in the organisation."
        ),
        build=_hn_mailinglist_dmarc,
    ),
    HardCase(
        "HN-CONFERENCE",
        0,
        "Academic committee invitation from an unknown domain",
        defeats="domain reputation",
        rationale=(
            "Conference domains are registered a few months before the event, "
            "used once, and abandoned -- a lifecycle indistinguishable from "
            "disposable attacker infrastructure."
        ),
        build=_hn_conference,
    ),
    HardCase(
        "HN-REAL-RESET",
        0,
        "The genuine password reset the clone copies",
        defeats="text content",
        rationale=(
            "This is the exact message that HP-CLONE imitates, sent from the "
            "real domain. The pair is the benchmark's control: a system that "
            "separates them is using provenance, and a system that scores them "
            "alike is reading the words."
        ),
        build=_hn_real_reset,
    ),
    # ---------------------------------------------------------- positives
    HardCase(
        "HP-CLONE",
        1,
        "Word-perfect brand clone, fully authenticated",
        defeats="text content",
        rationale=(
            "Phishing kits ship with the real email copied verbatim; only the "
            "link and the sending domain change. The attacker publishes SPF, "
            "signs with DKIM and aligns DMARC on their own lookalike domain, so "
            "authentication passes. Nothing in the language is wrong."
        ),
        build=_hp_clone_auth_pass,
    ),
    HardCase(
        "HP-BEC",
        1,
        "Business email compromise with no link and no attachment",
        defeats="URL and attachment features",
        rationale=(
            "The opening message of a BEC chain carries no payload at all -- it "
            "exists to get a reply. Every URL and attachment feature is zero, "
            "so a detector built on payload analysis has nothing to look at."
        ),
        build=_hp_bec_nolink,
    ),
    HardCase(
        "HP-COMPROMISED",
        1,
        "Phish from a genuine internal account, 318 prior messages",
        defeats="sender history",
        rationale=(
            "When an internal mailbox is taken over, every provenance signal "
            "endorses the attacker: real domain, passing authentication, years "
            "of history, internal sender. This is the case where relationship "
            "trust becomes a liability."
        ),
        build=_hp_compromised_internal,
    ),
    HardCase(
        "HP-TRUSTED-HOST",
        1,
        "Credential page hosted on a reputable platform",
        defeats="URL reputation",
        rationale=(
            "The landing page sits on a domain that cannot be blocklisted "
            "without breaking normal business use. Reputation lookups return "
            "'good' because the host really is good; the content on it is not."
        ),
        build=_hp_trusted_host,
    ),
    HardCase(
        "HP-REDIRECT",
        1,
        "Attack laundered through an open redirect on a trusted domain",
        defeats="URL reputation",
        rationale=(
            "The link a user hovers and a scanner resolves belongs to a "
            "well-known brand; the redirect parameter carries the real "
            "destination. Only a detector that parses the query string sees the "
            "attack."
        ),
        build=_hp_open_redirect,
    ),
    HardCase(
        "HP-AGED",
        1,
        "Attack from a six-year-old repurposed domain",
        defeats="domain age",
        rationale=(
            "Expired domains are bought precisely to defeat age heuristics. A "
            "2,140-day-old domain reads as established infrastructure on every "
            "age-based feature."
        ),
        build=_hp_aged_domain,
    ),
    HardCase(
        "HP-HOMOGLYPH",
        1,
        "Lookalike domain using character substitution",
        defeats="human reading",
        rationale=(
            "The substitution survives a careful human glance at the address "
            "bar. It is caught by string-distance comparison against a brand "
            "list, not by reading."
        ),
        build=_hp_homoglyph,
    ),
    HardCase(
        "HP-CALLBACK",
        1,
        "Callback phishing: a phone number instead of a link",
        defeats="URL features entirely",
        rationale=(
            "Telephone-oriented attack delivery moves the attack off email "
            "altogether. The message is a plausible receipt; the payload is the "
            "number the victim dials. All 107 URL features are zero."
        ),
        build=_hp_callback,
    ),
    HardCase(
        "HP-HIJACK",
        1,
        "Reply injected into a real, ongoing thread",
        defeats="thread and history context",
        rationale=(
            "Thread hijacking quotes genuine earlier correspondence, so thread "
            "depth, prior-reply count and topical coherence all vouch for the "
            "message. The user is expecting exactly this reply."
        ),
        build=_hp_thread_hijack,
    ),
    HardCase(
        "HP-IBAN",
        1,
        "Invoice fraud: correct relationship, changed bank details",
        defeats="sender history",
        rationale=(
            "A real supplier, a real invoice number, a real amount, 47 prior "
            "messages -- and new payment details. The fraud is one changed fact "
            "inside an otherwise entirely genuine message."
        ),
        build=_hp_invoice_iban,
    ),
    HardCase(
        "HP-QR",
        1,
        "QR-code phishing with no textual URL",
        defeats="URL extraction",
        rationale=(
            "The destination is encoded in an inline image, so URL extraction "
            "returns nothing. Detection has to fall back on sender provenance "
            "and the mismatch between an internal-sounding sender and an "
            "external domain."
        ),
        build=_hp_qr,
    ),
    HardCase(
        "HP-SLOWDRIP",
        1,
        "Low-volume spear phish with no urgency cues",
        defeats="behavioural campaign signals",
        rationale=(
            "One recipient, no burst, an aged domain, and deliberately relaxed "
            "wording -- 'no rush on this'. Every campaign-shaped behavioural "
            "feature is neutral, which is what a patient attacker buys with "
            "volume restraint."
        ),
        build=_hp_slow_drip,
    ),
)


def case_index() -> dict[str, HardCase]:
    return {c.case_id: c for c in HARD_CASES}


def build_hard_benchmark(
    *,
    variants_per_case: int = 8,
    seed: int = 20260912,
    start: datetime | None = None,
) -> tuple[list[EmailMessage], list[int], list[dict[str, Any]]]:
    """Materialise PG-HARD.

    Returns ``(messages, labels, meta)`` where ``meta[i]`` describes the case
    that produced ``messages[i]``. Deterministic for a given seed, so a run of
    the evaluation is reproducible from the manifest alone.
    """
    start = start or datetime(2026, 6, 1, tzinfo=timezone.utc)
    messages: list[EmailMessage] = []
    labels: list[int] = []
    meta: list[dict[str, Any]] = []

    for case in HARD_CASES:
        for k in range(variants_per_case):
            # Seed per (case, variant) so adding a case never renumbers the
            # variants of the cases before it.
            rng = random.Random(f"{seed}|{case.case_id}|{k}")  # noqa: S311 - seeded test data
            msg = case.build(Variant(rng))
            msg = msg.copy(
                received_at=start + timedelta(hours=len(messages) * 0.37),
                source=f"pg-hard:{case.case_id}",
                # One group per case: variants of a case must never be split
                # across train and test if this set is ever used for fitting.
                group_key=f"pg-hard/{case.case_id}",
            )
            messages.append(msg)
            labels.append(case.label)
            meta.append(
                {
                    "case_id": case.case_id,
                    "variant": k,
                    "label": case.label,
                    "family": case.family,
                    "title": case.title,
                    "defeats": case.defeats,
                    "rationale": case.rationale,
                    "tolerated": list(case.tolerated),
                }
            )

    return messages, labels, meta


def describe_benchmark() -> dict[str, Any]:
    """Machine-readable description, for the model card and the console."""
    return {
        "benchmark": BENCHMARK_ID,
        "n_cases": len(HARD_CASES),
        "n_hard_negatives": sum(1 for c in HARD_CASES if c.label == 0),
        "n_hard_positives": sum(1 for c in HARD_CASES if c.label == 1),
        "grading": {
            "tolerated_for_phish": list(TOLERATED_PHISH),
            "tolerated_for_ham": list(TOLERATED_HAM),
            "headline_failures": {
                "silent_delivery": "a hard positive that received ALLOW",
                "false_block": "a hard negative that received BLOCK",
            },
        },
        "defeated_signals": sorted({c.defeats for c in HARD_CASES}),
        "cases": [
            {
                "case_id": c.case_id,
                "label": c.label,
                "family": c.family,
                "title": c.title,
                "defeats": c.defeats,
                "rationale": c.rationale,
                "tolerated": list(c.tolerated),
            }
            for c in HARD_CASES
        ],
    }
