"""Content-addressed dataset versions.

A result is only reproducible if the data it came from can be named exactly.
"synthetic, n=9000, seed 20260907" is a recipe; the fingerprint is the dish.
It is a SHA-256 over every message's content digest and label, taken in sorted
order so it does not depend on how the corpus was shuffled or split, and it is
recorded in the model manifest and in the evaluation report.

Two consequences worth having:

* **Regenerating the corpus on another machine can be checked, not assumed.**
  The generator is deterministic by design; the fingerprint is how an examiner
  confirms that their copy is the one the dossier was computed on.
* **A silently changed corpus changes the version.** One flipped label, one
  edited body or one added message produces a different fingerprint, so a
  model and a report can never quietly disagree about what they were built on.

Only digests are hashed and stored -- never text -- so a fingerprint of a real
corpus reveals nothing about the mail in it.
"""

from __future__ import annotations

import hashlib
from collections import Counter
from collections.abc import Sequence
from typing import Any


def _message_digest(message: Any, label: int) -> str:
    parts = (
        str(int(label)),
        message.sender or "",
        message.subject or "",
        message.body or "",
        message.html_body or "",
        message.received_at.isoformat() if getattr(message, "received_at", None) else "",
    )
    return hashlib.sha256("\x1f".join(parts).encode("utf-8", "surrogatepass")).hexdigest()


def dataset_fingerprint(messages: Sequence[Any], labels: Sequence[int]) -> dict[str, Any]:
    """An order-independent version of a labelled corpus."""
    if len(messages) != len(labels):
        raise ValueError("messages and labels must be the same length")
    digests = sorted(_message_digest(m, y) for m, y in zip(messages, labels, strict=True))
    root = hashlib.sha256("\n".join(digests).encode("ascii")).hexdigest()
    sources = Counter(str(getattr(m, "source", "") or "unknown").split(":")[0] for m in messages)
    return {
        "sha256": root,
        "version": root[:12],
        "n": len(messages),
        "n_phishing": int(sum(int(y) for y in labels)),
        "sources": dict(sorted(sources.items())),
    }
